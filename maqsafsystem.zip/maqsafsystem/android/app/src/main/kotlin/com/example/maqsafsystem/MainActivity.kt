package com.example.maqsafsystem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
