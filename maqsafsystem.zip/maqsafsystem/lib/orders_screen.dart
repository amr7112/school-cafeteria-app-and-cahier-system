import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
class OrdersScreen extends StatefulWidget {
  final String cashierName;
  OrdersScreen({required this.cashierName});

  @override
  _OrdersScreenState createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  List students = [];
  List filteredStudents = [];
  bool isLoading = true;
  DateTime selectedDate = DateTime.now(); // ✅ التاريخ المختار

  @override
  void initState() {
    super.initState();
    fetchStudents(); // جلب الطلاب عند تحميل الشاشة
  }

  // ✅ جلب الطلاب الذين لديهم حجوزات فقط (مع أو بدون تاريخ)


  Future<void> fetchStudents({String? date}) async {
    String formattedDate = date ??
        "${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}";

    try {
      final response = await http.get(Uri.parse(
          date == null
              ? 'http://192.168.49.1/login/get_students.php' // جميع الطلاب الذين لديهم حجوزات
              : 'http://192.168.49.1/login/get_students.php?date=$formattedDate' // الطلاب حسب التاريخ
      ));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            students = data['students'] ?? [];
            filteredStudents = students;
            isLoading = false;
          });
        } else {
          setState(() {
            students = [];
            filteredStudents = [];
            isLoading = false;
          });
        }
      } else {
        print("HTTP Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching students: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  void filterStudents(String query) {
    setState(() {
      filteredStudents = students.where((student) {
        return student['name'].toLowerCase().contains(query.toLowerCase());
      }).toList();
    });
  }

  void navigateToStudentOrders(String studentId, String studentName) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => StudentOrdersScreen(
        studentId: studentId,
        studentName: studentName,
        cashierName: widget.cashierName,
      )),
    );
  }

  // ✅ اختيار التاريخ
  Future<void> selectDate(BuildContext context) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2024, 1, 1),
      lastDate: DateTime(2025, 12, 31),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
      fetchStudents(date: "${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}");
    }
  }

  // ✅ عرض جميع الطلاب الذين لديهم حجوزات
  void showAllStudents() {
    fetchStudents(); // جلب جميع الطلاب الذين لديهم حجوزات
  }

  @override
  Widget build(BuildContext context) {
    String todayDate = "${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}";

    return Scaffold(
      appBar: AppBar(title: Text('📋 قائمة الطلبات')),
      body: Column(
        children: [
          // ✅ اختيار التاريخ
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "📅 التاريخ: $todayDate",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                ElevatedButton.icon(
                  onPressed: () => selectDate(context),
                  icon: Icon(Icons.calendar_today),
                  label: Text("اختر تاريخ"),
                ),
              ],
            ),
          ),
          //  زر عرض جميع الطلاب الذين لديهم حجوزات
          Padding(
            padding: EdgeInsets.all(10),
            child: ElevatedButton.icon(
              onPressed: showAllStudents,
              icon: Icon(Icons.list),
              label: Text("عرض الكل"),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              decoration: InputDecoration(
                hintText: '🔍 بحث باسم الطالب...',
                border: OutlineInputBorder(),
                suffixIcon: Icon(Icons.search),
              ),
              onChanged: filterStudents,
            ),
          ),
          //  عرض قائمة الطلاب
          Expanded(
            child: isLoading
                ? Center(child: CircularProgressIndicator())
                : ListView.builder(
              itemCount: filteredStudents.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(filteredStudents[index]['name']),
                  subtitle: Text("الرقم: ${filteredStudents[index]['id']}"),
                  trailing: Icon(Icons.arrow_forward_ios),
                  onTap: () => navigateToStudentOrders(
                    filteredStudents[index]['id'],
                    filteredStudents[index]['name'],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
class StudentOrdersScreen extends StatefulWidget {
  final String studentId;
  final String studentName;
  final String cashierName;
  StudentOrdersScreen({required this.studentId, required this.studentName, required this.cashierName});

  @override
  _StudentOrdersScreenState createState() => _StudentOrdersScreenState();
}

class _StudentOrdersScreenState extends State<StudentOrdersScreen> {
  List orders = [];
  bool isLoading = true;
  DateTime selectedDate = DateTime.now(); // التاريخ المختار
  bool isFull= false;

  @override
  void initState() {
    super.initState();
    fetchOrders(); // جلب الطلبات عند تحميل الشاشة
  }

  // جلب الطلبات الخاصة بالطالب حسب التاريخ (إذا تم تحديد تاريخ)
  Future<void> fetchOrders({String? date}) async {
    String formattedDate = date ?? "";  // إذا كان التاريخ فارغًا، سيتم إرساله بدون تاريخ.

    try {
      final response = await http.get(Uri.parse(
          'http://192.168.49.1/login/get_student_orders.php?student_id=${widget.studentId}&date=$formattedDate'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
         print(data);
        if (data['status'] == 'success') {
          setState(() {
            orders = data['orders']
                .where((order) => order['status'] != 'مستلم')
                .toList();
            isLoading = false;
          });
        } else {
          setState(() {
            orders = [];
            isLoading = false;
          });
        }
      }
    } catch (e) {
      print("Error fetching orders: $e");
    }
  }

// زر "عرض الكل"
  void showAllOrders() {
    fetchOrders();  // سيتم جلب جميع الطلبات بدون تحديد تاريخ
  }

  // اختيار التاريخ
  Future<void> selectDate(BuildContext context) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2024, 1, 1),
      lastDate: DateTime(2025, 12, 31),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
      fetchOrders(date: "${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}");
    }
  }

  // عرض جميع الطلبات بدون تاريخ


  Future<void> confirmOrder(String orderId) async {
    try {
      final response = await http.post(
        Uri.parse('http://192.168.49.1/login/confirm_order2.php'),
        body: {
          'order_id': orderId,
          'cashier_name': widget.cashierName,
          'student_id': widget.studentId,
        },
      );

      final data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          orders.removeWhere((order) => order['order_id'] == orderId);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("✅ تم ترحيل الطلب بنجاح")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ فشل في ترحيل الطلب")),
        );
      }
    } catch (e) {
      print("Error confirming order: $e");
    }
  }
  // إلغاء الطلب
  Future<void> cancelOrder(String orderId) async {
    try {
      final response = await http.post(
        Uri.parse('http://192.168.49.1/login/cancel_order.php'),
        body: {
          'order_id': orderId,  // يتم إرسال "id" هنا
          'student_id': widget.studentId,
        },
      );

      final data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          orders.removeWhere((order) => order['order_id'] == orderId);  // التعديل ليكون على "id"
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌تم إلغاء الطلب بنجاح وتم اضافه الرصيد")),
        );
      } else {
        print(data['status']);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ فشل في إلغاء الطلب")),
        );
      }
    } catch (e) {
      print("Error cancelling order: $e");
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("طلبات ${widget.studentName}")),
      body: Column(
        children: [
          // اختيار التاريخ
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "📅 التاريخ: ${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                ElevatedButton.icon(
                  onPressed: () => selectDate(context),
                  icon: Icon(Icons.calendar_today),
                  label: Text("اختر تاريخ"),
                ),
              ],
            ),
          ),
          // زر عرض جميع الطلبات
          Padding(
            padding: EdgeInsets.all(10),
            child: ElevatedButton.icon(
              onPressed: showAllOrders,
              icon: Icon(Icons.list),
              label: Text("عرض الكل"),
            ),
          ),
          // عرض الطلبات
          isLoading
              ? Center(child: CircularProgressIndicator())
              : orders.isEmpty
              ? Center(child: Text("لا يوجد طلبات"))
              : // عرض الطلبات
          Expanded(
            child: ListView.builder(
              itemCount: orders.length,
              itemBuilder: (context, index) {
                if (orders[index]['note'] != null && orders[index]['note'].toString().trim().isNotEmpty) {
                  isFull = true;
                } else {
                  isFull = false;
                }

                return Card(
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    title: Text(orders[index]['Product_name']),
                    subtitle: Text(
                        "الكمية: ${orders[index]['quantity']}\nالسعر: ${orders[index]['total_price']} ريال\nاليوم: ${orders[index]['day']}\nملاحظة: ${orders[index]['note']}"),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // زر تأكيد
                        ElevatedButton(
                          onPressed: (orders[index]['note'].toString().trim().isNotEmpty)?
                    () => confirmOrder(orders[index]['order_id'].toString()):null,
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                          child: Text("تأكيد"),
                        ),
                        SizedBox(width: 10),
                        // زر إلغاء
                        ElevatedButton(
                          onPressed:(orders[index]['note'] == null || orders[index]['note'].toString().trim().isEmpty)?
                              () => cancelOrder(orders[index]['order_id'].toString()):null,
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                          child: Text("إلغاء"),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

        ],
      ),
    );
  }
}
