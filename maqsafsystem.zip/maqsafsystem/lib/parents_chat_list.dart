import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:maqsafsystem/group_chat_screen.dart';
import 'chat_screen.dart';

class ParentsChatScreen extends StatefulWidget {
  @override
  _ParentsChatScreenState createState() => _ParentsChatScreenState();
}

class _ParentsChatScreenState extends State<ParentsChatScreen> {
  List<Map<String, dynamic>> parents = [];
  List<Map<String, dynamic>> groupMessages = [];
  bool isLoading = true;
  TextEditingController searchController = TextEditingController();
  Timer? _timer;

  @override
  @override
  void initState() {
    super.initState();

    // تحميل البيانات لأول مرة مع isLoading = true
    fetchParents(initialLoad: true);
    fetchGroupMessages(initialLoad: true);

    // تحديث البيانات كل 10 ثوانٍ بدون تغيير حالة isLoading
    _timer = Timer.periodic(Duration(seconds: 10), (timer) {
      fetchParents();
      fetchGroupMessages();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // 🔹 جلب قائمة أولياء الأمور
  Future<void> fetchParents({bool initialLoad = false}) async {
    if (initialLoad) {
      setState(() {
        isLoading = true;
      });
    }

    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/login/get_parents_chats.php'));
      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        if (jsonData is List) {
          setState(() {
            parents = jsonData.map<Map<String, dynamic>>((parent) {
              parent['unread_count'] = int.tryParse(parent['unread_count'].toString()) ?? 0;
              parent['formatted_time'] = parent['last_message_time'] != null
                  ? DateFormat('hh:mm a, yyyy-MM-dd').format(
                  DateTime.fromMillisecondsSinceEpoch(int.tryParse(parent['last_message_time'].toString()) ?? 0))
                  : "لا توجد رسائل";
              return parent;
            }).toList();

            // ترتيب حسب أحدث رسالة
            parents.sort((a, b) => (b['last_message_time'] ?? 0).compareTo(a['last_message_time'] ?? 0));

            // تحديث حالة التحميل
            isLoading = false;
          });
        }
      }
    } catch (e) {
      print('❌ خطأ أثناء جلب البيانات: $e');
    }
  }

  // 🔹 تحديث حالة الرسائل إلى "مقروءة"
  Future<void> markMessagesAsRead(String parentId) async {
    await http.post(
      Uri.parse('http://192.168.49.1/login/mark_as_read.php'),
      body: {"parent_id": parentId},
    );

    setState(() {
      for (var parent in parents) {
        if (parent['parent_id'] == parentId) {
          parent['unread_count'] = 0;
        }
      }
    });
  }

  // 🔹 جلب آخر رسالة في المحادثة الجماعية
// 🔹 جلب آخر رسالة في المحادثة الجماعية
  Future<void> fetchGroupMessages({bool initialLoad = false}) async {
    if (initialLoad) {
      setState(() {
        isLoading = true;
      });
    }

    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/login/get_group_messages.php'));
      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        if (jsonData is List) {
          setState(() {
            groupMessages = List<Map<String, dynamic>>.from(jsonData);

            if (groupMessages.isNotEmpty) {
              var lastMessage = groupMessages.last;
              lastMessage['formatted_time'] = DateFormat('hh:mm a, yyyy-MM-dd').format(
                  DateTime.fromMillisecondsSinceEpoch(int.tryParse(lastMessage['timestamp'].toString()) ?? 0));
            } else {
              // إذا لم تكن هناك رسائل في المجموعة، ضع تاريخ افتراضي
              groupMessages = [
                {
                  'formatted_time': "لا توجد رسائل",
                }
              ];
            }

            // تحديث حالة التحميل
            isLoading = false;
          });
        }
      }
    } catch (e) {
      print('❌ خطأ أثناء جلب رسائل المجموعة: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("المحادثات"),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              fetchParents();
              fetchGroupMessages();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: "بحث...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onChanged: (query) {
                setState(() {
                  parents = parents.where((parent) {
                    return parent['parent_name'].toLowerCase().contains(query.toLowerCase());
                  }).toList();
                });
              },
            ),
          ),
          Expanded(
            child: isLoading
                ? Center(child: CircularProgressIndicator())
                : ListView.builder(
              itemCount: parents.length + 1, // +1 لإضافة المحادثة الجماعية
              itemBuilder: (context, index) {
                if (index == 0) {
                  // المحادثة الجماعية
                  return ListTile(
                    title: Text("المحادثة الجماعية", style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(groupMessages.isNotEmpty
                        ? "آخر رسالة: ${groupMessages.last['formatted_time']}"
                        : "لا توجد رسائل بعد"),
                    leading: Icon(Icons.group, color: Colors.blue),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => GroupChatScreen(currentUserId: "admin"),
                        ),
                      );
                    },
                  );

                } else {
                  // محادثات أولياء الأمور
                  var parent = parents[index - 1];
                  return ListTile(
                    title: Text(parent['parent_name']),
                    subtitle: Text("آخر رسالة: ${parent['formatted_time']}"),
                    trailing: parent['unread_count'] > 0
                        ? CircleAvatar(
                      radius: 12,
                      backgroundColor: Colors.red,
                      child: Text(
                        parent['unread_count'].toString(),
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    )
                        : Icon(Icons.chat, color: Colors.teal),
                    onTap: () async {
                      await markMessagesAsRead(parent['parent_id']);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ChatScreen(
                            currentUserId: "admin",
                            receiverId: parent['parent_id'],
                            receiverName: parent['parent_name'],
                          ),
                        ),
                      );
                    },
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
