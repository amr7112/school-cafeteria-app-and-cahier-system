import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';
import 'package:http_parser/http_parser.dart';

class AddProductScreen extends StatefulWidget {
  @override
  _AddProductScreenState createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController noteController = TextEditingController();
  String? selectedCategoryId;
  List<dynamic> categories = [];
  File? _image;

  @override
  void initState() {
    super.initState();
    fetchCategories();
  }

  Future<void> fetchCategories() async {
    var uri = Uri.parse("http://192.168.49.1/login/get_categories1.php");
    var response = await http.get(uri);

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          categories = data['categories'];
          if (categories.isNotEmpty) {
            selectedCategoryId = categories[0]['Category_id'].toString();
          }
        });
      }
    }
  }

  Future<void> pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> addProduct() async {
    var uri = Uri.parse("http://192.168.49.1/login/add_product.php");
    var request = http.MultipartRequest('POST', uri);

    request.fields['Product_name'] = nameController.text;
    request.fields['Product_price'] = priceController.text;
    request.fields['Product_description'] = descriptionController.text;
    request.fields['category_id'] = selectedCategoryId ?? "";
    request.fields['note'] = noteController.text;

    if (_image != null) {
      var mimeType = lookupMimeType(_image!.path);
      request.files.add(
        await http.MultipartFile.fromPath(
          'Product_image_url',
          _image!.path,
          contentType: MediaType.parse(mimeType ?? 'image/jpeg'),
        ),
      );
    }

    var response = await request.send();
    var responseString = await response.stream.bytesToString();
    var jsonResponse = json.decode(responseString);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(jsonResponse['message'])),
    );
  }

  Future<void> addCategory(String categoryName) async {
    if (categoryName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("الرجاء إدخال اسم الفئة")),
      );
      return;
    }

    try {
      var uri = Uri.parse("http://192.168.49.1/login/add_category.php");

      var response = await http.post(uri, body: {
        'Category_name': categoryName, // إرسال اسم الفئة
      });

      if (response.statusCode == 200) {
        var jsonResponse = json.decode(response.body);
        print(jsonResponse['message']); // ✅ تصحيح الخطأ في الطباعة

        if (jsonResponse['status'] == "error") {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(jsonResponse['message'])),
          );
          return;
        }

        if (jsonResponse['status'] == "success") {
          fetchCategories(); // تحديث قائمة الفئات بعد الإضافة
          Navigator.pop(context); // إغلاق النافذة
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("تمت إضافة الفئة بنجاح")),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("حدث خطأ أثناء الاتصال بالخادم")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("خطأ في الاتصال: $e")),
      );
    }
  }
  
  void showAddCategoryDialog() {
    TextEditingController categoryController = TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("إضافة فئة جديدة"),
          content: TextField(
            controller: categoryController,
            decoration: InputDecoration(labelText: "اسم الفئة"),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("إلغاء"),
            ),
            ElevatedButton(
              onPressed: () {
                if (categoryController.text.isNotEmpty) {
                  addCategory(categoryController.text);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("الرجاء إدخال اسم الفئة")),
                  );
                }
              },
              child: Text("إضافة فئة"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("إضافة منتج"),
      backgroundColor: Color(0xFF2B7A5B),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextField(controller: nameController, decoration: InputDecoration(labelText: "اسم المنتج")),
              TextField(controller: priceController, decoration: InputDecoration(labelText: "سعر المنتج"),
                  keyboardType: TextInputType.number),
              TextField(controller: descriptionController, decoration: InputDecoration(labelText: "الوصف")),
              DropdownButtonFormField<String>(
                value: selectedCategoryId,
                decoration: InputDecoration(labelText: "الفئة"),
                items: categories.map((category) {
                  return DropdownMenuItem(
                    value: category['Category_id'].toString(),
                    child: Text(category['Category_name']),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedCategoryId = value;
                  });
                },
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  icon: Icon(Icons.add),
                  label: Text("إضافة فئة جديدة"),
                  onPressed: showAddCategoryDialog,
                ),
              ),
              TextField(controller: noteController, decoration: InputDecoration(labelText: "ملاحظات")),
              SizedBox(height: 10),
              _image == null
                  ? Text("لم يتم اختيار صورة")
                  : Image.file(_image!, height: 100),
              ElevatedButton(onPressed: pickImage, child: Text("اختيار صورة")),
              SizedBox(height: 10),
              ElevatedButton(onPressed: addProduct, child: Text("إضافة المنتج")),
            ],
          ),
        ),
      ),
    );
  }
}
