import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';

class SalesScreen extends StatefulWidget {
  @override
  _SalesScreenState createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  List<Map<String, dynamic>> sales = [];
  bool isLoading = true;
  DateTime? selectedDate;

  @override
  void initState() {
    super.initState();
    fetchSales();
  }

  Future<void> fetchSales() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/login/get_sales.php'));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        setState(() {
          sales = data.map((sale) => {
            "sale_id": sale["sale_id"],
            "total_price": double.parse(sale["total_price"].toString()),
            "cashier_name": sale["cashier_name"],
            "commission": double.parse(sale["commission"].toString()),
            "sale_date": sale["sale_date"],
            "student_name": sale["student_name"] ?? "غير معروف",
            "items": List<Map<String, dynamic>>.from(sale["items"]),
          }).toList();
          isLoading = false;

        });

      } else {
        throw Exception("فشل تحميل المبيعات (${response.statusCode})");
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("خطأ أثناء جلب المبيعات: ${e.toString()}")),
      );
    }
  }

  void _showFilterOptionsDialog() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: Icon(Icons.calendar_today),
            title: Text("تقرير يومي"),
            onTap: () {
              Navigator.pop(context);
              _selectDateAndGenerateReport("daily");
            },
          ),
          ListTile(
            leading: Icon(Icons.calendar_view_month),
            title: Text("تقرير شهري"),
            onTap: () {
              Navigator.pop(context);
              _selectDateAndGenerateReport("monthly");
            },
          ),
          ListTile(
            leading: Icon(Icons.yard),
            title: Text("تقرير سنوي"),
            onTap: () {
              Navigator.pop(context);
              _selectDateAndGenerateReport("yearly");
            },
          ),
        ],
      ),
    );
  }

  Future<void> _selectDateAndGenerateReport(String type) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      locale: Locale("ar", "YE"),
    );

    if (picked == null) return;

    setState(() => selectedDate = picked);

    List<Map<String, dynamic>> filteredSales = sales.where((sale) {
      final saleDate = DateTime.parse(sale['sale_date']);
      if (type == "daily") {
        return saleDate.year == picked.year &&
            saleDate.month == picked.month &&
            saleDate.day == picked.day;
      } else if (type == "monthly") {
        return saleDate.year == picked.year &&
            saleDate.month == picked.month;
      } else if (type == "yearly") {
        return saleDate.year == picked.year;
      }
      return false;
    }).toList();

    if (filteredSales.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("لا توجد مبيعات في هذا التاريخ")),
      );
    } else {
      await _printSalesByDate(filteredSales, picked, type);
    }
  }

  Future<void> _printSalesByDate(List<Map<String, dynamic>> salesList, DateTime date, String type) async {
    final pdf = pw.Document();
    final arabicFont = await rootBundle.load("assets/fonts/Amiri-Regular.ttf");
    final ttf = pw.Font.ttf(arabicFont);

    String title;
    if (type == "daily") {
      title = "تقرير مبيعات ليوم ${DateFormat('yyyy-MM-dd').format(date)}";
    } else if (type == "monthly") {
      title = "تقرير مبيعات لشهر ${DateFormat('yyyy-MM').format(date)}";
    } else {
      title = "تقرير مبيعات لسنة ${DateFormat('yyyy').format(date)}";
    }

    double totalAllSales = salesList.fold(0.0, (sum, sale) => sum + sale['total_price']);

    pdf.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(base: ttf),
        pageFormat: PdfPageFormat.a4,
        textDirection: pw.TextDirection.rtl,
        build: (context) {
          List<pw.Widget> content = [];

          // العنوان الرئيسي
          content.add(
            pw.Text(title, style: pw.TextStyle(fontSize: 22)),
          );
          content.add(pw.SizedBox(height: 10));

          // كل فاتورة
          for (var sale in salesList) {
            content.add(
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text("فاتورة رقم: ${sale['sale_id']}"),
                  pw.Text("الطالب: ${sale['student_name']}"),
                  pw.Text("الكاشير: ${sale['cashier_name']}"),
                  pw.Text("الوقت: ${sale['sale_date']}"),
                  pw.SizedBox(height: 5),
                  pw.Table.fromTextArray(
                    headers: ['الاجمالي','العمولة', 'السعر', 'الكمية', 'المنتج'],
                    data: List<List<String>>.from(
                      sale['items'].map((item) {
                        final qty = int.parse(item['quantity'].toString());
                        final price = double.parse(item['price_per_unit'].toString());
                        final commission = double.tryParse("${sale['commission']}".toString()) ?? 0.0;
                        final total = (qty * price) + commission;
                        return [
                          total.toStringAsFixed(2),
                          commission.toStringAsFixed(2),
                          price.toStringAsFixed(2),
                          qty.toString(),
                          item['Product_name'].toString(),

                        ];
                      }),
                    ),
                    cellStyle: pw.TextStyle(font: ttf, fontSize: 10),
                    headerStyle: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.normal),
                    cellAlignment: pw.Alignment.centerRight,
                  ),
                  pw.SizedBox(height: 10),
                  pw.Text("الإجمالي: ${sale['total_price']} ر.ي", style: pw.TextStyle(fontSize: 14)),
                  pw.Divider(),
                ],
              ),
            );
          }

          // الإجمالي الكلي
          content.add(pw.SizedBox(height: 20));
          content.add(
            pw.Text(
              "الإجمالي الكلي للمبيعات: ${totalAllSales.toStringAsFixed(2)} ر.ي",
              style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.normal),
            ),
          );

          return content;
        },
      ),
    );

    await Printing.layoutPdf(onLayout: (format) => pdf.save());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("سجل المبيعات"),
        backgroundColor: Color(0xFF2B7A5B),
        actions: [
          IconButton(
            icon: Icon(Icons.print),
            onPressed: _showFilterOptionsDialog,
            tooltip: "طباعة حسب التاريخ",
          )
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF2B7A5B)))
          : ListView.builder(
        padding: EdgeInsets.all(10),
        itemCount: sales.length,
        itemBuilder: (context, index) {
          var sale = sales[index];
          return SaleCard(sale: sale);
        },
      ),
    );
  }
}



class SaleCard extends StatelessWidget {
  final Map<String, dynamic> sale;

  const SaleCard({required this.sale});

  void printInvoice(BuildContext context, Map<String, dynamic> sale) async {
    final pdf = pw.Document();
    final arabicFont = await rootBundle.load("assets/fonts/Amiri-Regular.ttf");
    final ttf = pw.Font.ttf(arabicFont);
    final formatter = DateFormat('yyyy-MM-dd HH:mm:ss');

    pdf.addPage(
      pw.Page(
        theme: pw.ThemeData.withFont(base: ttf),
        build: (context) {
          return pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text("فاتورة بيع", style: pw.TextStyle(fontSize: 24)),
                pw.SizedBox(height: 10),
                pw.Text("رقم الفاتورة: ${sale['sale_id']}"),
                pw.Text("اسم الطالب: ${sale['student_name']}"),
                pw.Text("الكاشير: ${sale['cashier_name']}"),
                pw.Text("تاريخ العملية: ${sale['sale_date']}"),
                pw.SizedBox(height: 15),
                pw.Text("المنتجات:", style: pw.TextStyle(fontSize: 20)),
                pw.SizedBox(height: 5),
                pw.Table.fromTextArray(
                  headers: ['الإجمالي', 'العمولة', 'السعر', 'الكمية', 'المنتج'],
                  data: List<List<String>>.from(
                    sale['items'].map((item) {
                      final qty = int.tryParse(item['quantity'].toString()) ?? 0;
                      final price = double.tryParse(item['price_per_unit'].toString()) ?? 0.0;
                      final commission = double.tryParse("${sale['commission']}".toString()) ?? 0.0;
                      final total = (qty * price) + commission;
                      return [
                        total.toStringAsFixed(2),
                        commission.toStringAsFixed(2),
                        price.toStringAsFixed(2),
                        qty.toString(),
                        item['Product_name'].toString(),
                      ];
                    }),
                  ),
                  cellStyle: pw.TextStyle(font: ttf),
                  headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.normal, fontSize: 14),
                  cellAlignment: pw.Alignment.centerRight,
                ),
                pw.SizedBox(height: 10),
                pw.Text("الإجمالي الكلي: ${sale['total_price']} ر.ي", style: pw.TextStyle(fontSize: 24)),
                pw.Spacer(),
                pw.Align(
                  alignment: pw.Alignment.centerRight,
                  child: pw.Text("تاريخ الطباعة: ${formatter.format(DateTime.now())}",
                      style: pw.TextStyle(fontSize: 12)),
                ),
              ],
            ),
          );
        },
      ),
    );

    await Printing.layoutPdf(onLayout: (format) => pdf.save());
  }

  @override
  Widget build(BuildContext context) {
    final items = sale["items"];

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.only(bottom: 15),
      elevation: 5,
      color: Colors.white,
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // العنوان العلوي
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("رقم الفاتورة: ${sale['sale_id']}",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),


              ],
            ),
            SizedBox(height: 5),
            Text("الطالب: ${sale['student_name']}",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
            SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("الكاشير: ${sale['cashier_name']}", style: TextStyle(color: Colors.blue, fontSize: 14)),
                Text(sale["sale_date"], style: TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
            Divider(),
            // تفاصيل المنتجات
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: items.map<Widget>((item) {
                final qty = int.tryParse(item["quantity"].toString()) ?? 0;
                final price = double.tryParse(item["price_per_unit"].toString()) ?? 0.0;
                final commission = double.tryParse("${sale['commission']}".toString()) ?? 0.0;
                final total = (qty * price) + commission;


                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(item['Product_name'], style: TextStyle(fontWeight: FontWeight.w500)),
                      Text(
                        "$qty × ${price.toStringAsFixed(2)} + ${commission.toStringAsFixed(2)} = ${total.toStringAsFixed(2)} ر.ي",
                        style: TextStyle(color: Colors.black54),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,

              children: [
                Align(
                  child: InkWell(
                    onTap: () => printInvoice(context, sale),
                    child: Chip(
                      label: Text("طباعة"),
                      backgroundColor: Colors.green.shade100,
                    ),

                  ),
                ),
                Align(
                    child:Chip(
                      label:Text("${sale['total_price']} ر.ي"),
                      backgroundColor: Colors.green.shade100,
                    )

                ),
              ],
            ),

          ],
        ),
      ),
    );
  }
}
