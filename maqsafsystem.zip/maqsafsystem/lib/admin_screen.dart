import 'package:flutter/material.dart';
import 'package:maqsafsystem/add_cashier_screen.dart';
import 'package:maqsafsystem/add_student_screen.dart';
import 'package:maqsafsystem/control_product.dart';
import 'package:maqsafsystem/parent_screen.dart';
import 'package:maqsafsystem/parents_chat_list.dart';
import 'package:maqsafsystem/sales_screen.dart';

class AdminScreen extends StatelessWidget {
  final String username;
  final String user_id;

  const AdminScreen({super.key, required this.username, required this.user_id});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("🔹لوحة تحكم المدير"),
        backgroundColor: const Color(0xFF2B7A5B),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "👋 مرحبًا، $username",
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 30),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,
                children: [
                  MenuButton(
                    icon: Icons.receipt,
                    text: "📋 سجل المبيعات",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SalesScreen()),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.person_add,
                    text: "➕ إضافة كاشير",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => AddCashierScreen()),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.chat,
                    text: "💬 المحادثات مع أولياء الأمور",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ParentsChatScreen(
                                // username: username,
                                // user_id:user_id
                                )),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.chat,
                    text: "💳 محفظة رصيد أولياء الأمور",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ParentsScreen(
                                // username: username,
                                // user_id:user_id
                                )),
                      );
                    },
                  ),
                  MenuButton(
                      icon: Icons.add,
                      text: "اضافه طالب جديد",
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const AddStudentScreen()));
                      }),
                  MenuButton(
                      icon: Icons.control_camera,
                      text: "🎛التحكم بالمنتجات",
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => controlProduct()));
                      }),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MenuButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const MenuButton(
      {super.key, required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFF2B7A5B), width: 2),
        ),
        elevation: 5,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 40, color: const Color(0xFF2B7A5B)),
          const SizedBox(height: 10),
          Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 16,
              color: Color(0xFF2B7A5B),
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
