import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:maqsafsystem/auth/login_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Maqsaf System',
      debugShowCheckedModeBanner: false,
      // ✅ أضف التالي لدعم التواريخ واللغة العربية
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: [
        const Locale('ar', 'YE'), // 🇾🇪 العربية - اليمن
        const Locale('en', 'US'), // 🇺🇸 الإنجليزية
      ],
      locale: const Locale('ar', 'YE'), // اجعل العربية هي الافتراضية إذا أردت
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Amiri', // لو كان لديك خط عربي مخصص
      ),
      home:login_Screen(),
    );
  }
}
