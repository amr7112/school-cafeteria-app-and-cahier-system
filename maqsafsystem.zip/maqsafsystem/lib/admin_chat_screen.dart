import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:maqsafsystem/chat_screen.dart';

class AdminChatScreen extends StatefulWidget {
  final String username; // اسم المدير

  AdminChatScreen({required this.username});

  @override
  _AdminChatScreenState createState() => _AdminChatScreenState();
}

class _AdminChatScreenState extends State<AdminChatScreen> {
  List<Map<String, dynamic>> conversations = [];

  @override
  void initState() {
    super.initState();
    fetchConversations();
  }

  Future<void> fetchConversations() async {
    final response = await http.get(Uri.parse("http://yourserver.com/get_conversations.php"));

    if (response.statusCode == 200) {
      setState(() {
        conversations = List<Map<String, dynamic>>.from(json.decode(response.body));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("💬 المحادثات")),
      body: ListView.builder(
        itemCount: conversations.length,
        itemBuilder: (context, index) {
          final convo = conversations[index];
          final employeeName = convo['employee_name'];
          final employeeId = convo['employee_id'];

          return ListTile(
            title: Text("👨‍💼 $employeeName"),
            subtitle: Text("📬 محادثة جارية"),
            trailing: Icon(Icons.chat, color: Colors.blue),
            onTap: () {
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => ChatScreen(
              //       currentUserId: widget.username,
              //       receiverId: employeeId,
              //       receiverName: widget.receiverName,
              //     ),
              //   ),
              // );
            },
          );
        },
      ),
    );
  }
}
