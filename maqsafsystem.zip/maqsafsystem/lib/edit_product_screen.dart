import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class EditProductScreen extends StatefulWidget {
  const EditProductScreen({super.key});

  @override
  State<EditProductScreen> createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  late TextEditingController nameController;
  late TextEditingController priceController;
  late TextEditingController descriptionController;
  late TextEditingController noteController;

  List<dynamic> products = [];
  List<dynamic> categories = [];
  String? selectedProductId;
  int? selectedCategoryId;
  String imageUrl = '';


  @override
  void initState() {
    super.initState();
    nameController = TextEditingController();
    priceController = TextEditingController();
    descriptionController = TextEditingController();
    noteController = TextEditingController();


    fetchCategories();
    fetchProducts();
  }

  Future<void> fetchCategories() async {
    var url = Uri.parse("http://192.168.49.1/login/get_categories.php");
    var response = await http.get(url);
    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      setState(() {
        categories = jsonResponse;
      });
    }
  }

  Future<void> fetchProducts() async {
    var url = Uri.parse("http://192.168.49.1/login/get_products.php");
    var response = await http.get(url);
    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);

      if (jsonResponse['status'] == 'success') {
        setState(() {
          products = jsonResponse['products'];
          if (products.isNotEmpty && selectedProductId == null) {
            selectedProductId = products[0]['id'].toString();
            fetchProductDetails(selectedProductId!);
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("فشل في جلب المنتجات: ${jsonResponse['message'] ?? ''}")),
        );
      }
    } else {
      print("Failed to fetch products, status code: ${response.statusCode}");
    }
  }

  Future<void> fetchProductDetails(String productId) async {
    var url = Uri.parse("http://192.168.49.1/login/get_product_details.php");
    var response = await http.post(url, body: {'Product_id': productId});
    var jsonResponse = json.decode(response.body);

    if (jsonResponse['status'] == 'success') {
      setState(() {
        nameController.text = jsonResponse['product']['Product_name'] ?? '';
        priceController.text = jsonResponse['product']['Product_price']?.toString() ?? '';
        descriptionController.text = jsonResponse['product']['Product_description'] ?? '';
        noteController.text = jsonResponse['product']['note'] ?? '';
        selectedCategoryId = int.tryParse(jsonResponse['product']['Category_id'].toString()) ?? null;

        // ✅ تحديث رابط الصورة هنا
        imageUrl = jsonResponse['product']['Product_image_url'] ?? '';
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("لم يتم العثور على المنتج")));
    }
  }
  Future<void> updateProduct() async {
    if (selectedProductId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("يرجى اختيار منتج لتحديثه")),
      );
      return;
    }

    var url = Uri.parse("http://192.168.49.1/login/update_product.php");
    var body = {
      'Product_id': selectedProductId!,
      'Product_name': nameController.text,
      'Product_price': priceController.text,
      'Product_description': descriptionController.text,
      'note': noteController.text,
    };
    if (selectedCategoryId != null) {
      body['Category_id'] = selectedCategoryId.toString();
    }

    var response = await http.post(url, body: body);
    var jsonResponse = json.decode(response.body);
    if (jsonResponse['status'] == 'success') {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("تم التحديث بنجاح")));
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("فشل في التحديث")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("تعديل المنتج"),
        backgroundColor: Color(0xFF2B7A5B),

      ),

      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // اختيار المنتج
              DropdownButton<String>(
                hint: const Text("اختر منتج"),
                value: selectedProductId != null &&
                    products.any((prod) => prod['id'].toString() == selectedProductId)
                    ? selectedProductId
                    : null,
                items: products.isNotEmpty
                    ? products.map<DropdownMenuItem<String>>((product) {
                  return DropdownMenuItem<String>(
                    value: product['id'].toString(),
                    child: Text(product['name'] ?? 'اسم المنتج غير متوفر'),
                  );
                }).toList()
                    : [],
                onChanged: (String? newValue) {
                  setState(() {
                    selectedProductId = newValue;
                    // إعادة تعيين الحقول لتظهر بيانات جديدة
                    nameController.clear();
                    priceController.clear();
                    descriptionController.clear();
                    noteController.clear();
                    selectedCategoryId = null;
                    imageUrl = ''; // تفريغ الصورة مؤقتًا
                  });
                  if (selectedProductId != null) {
                    fetchProductDetails(selectedProductId!);
                  }
                },
              ),
              const SizedBox(height: 20),

              // عرض صورة المنتج (تم التعديل هنا فقط)
              if (imageUrl.isNotEmpty)
                Image.network(
                  imageUrl,
                  height: 150,
                  width: 150,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.broken_image),
                )
              else
                const Text("لا توجد صورة للمنتج"),

              const SizedBox(height: 20),

              // اختيار الفئة
              DropdownButton<int>(
                hint: const Text("اختر فئة"),
                value: selectedCategoryId,
                items: categories.map<DropdownMenuItem<int>>((category) {
                  final int? id = int.tryParse(category['id'].toString());
                  return DropdownMenuItem<int>(
                    value: id,
                    child: Text(category['name'] ?? 'بدون اسم'),
                  );
                }).toList(),
                onChanged: (int? newValue) {
                  setState(() {
                    selectedCategoryId = newValue;
                  });
                },
              ),

              const SizedBox(height: 20),

              // حقول تعديل بيانات المنتج
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: "اسم المنتج"),
              ),
              TextField(
                controller: priceController,
                decoration: const InputDecoration(labelText: "السعر"),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: descriptionController,
                decoration: const InputDecoration(labelText: "الوصف"),
                maxLines: 3,
              ),
              TextField(
                controller: noteController,
                decoration: const InputDecoration(labelText: "ملاحظة"),
                maxLines: 2,
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: updateProduct,
                child: const Text("تحديث المنتج"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
