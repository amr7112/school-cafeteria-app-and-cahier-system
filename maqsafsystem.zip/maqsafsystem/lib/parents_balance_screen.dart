import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class BalanceScreen extends StatefulWidget {
  final String parentId;

  BalanceScreen({required this.parentId});

  @override
  _BalanceScreenState createState() => _BalanceScreenState();
}

class _BalanceScreenState extends State<BalanceScreen> {
  double balance = 0.0;
  bool isLoading = true;
  TextEditingController amountController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchBalance();
  }

  // 🔵 جلب الرصيد من قاعدة البيانات
  Future<void> fetchBalance() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/maqsaf_backend/parents/fetch_balance.php?parent_id=${widget.parentId}'));

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        if (decodedData['status'] == 'success') {
          setState(() {
            balance = double.tryParse(decodedData['balance']) ?? 0.0; // تأكد أن الرصيد لا يكون null
            isLoading = false;
          });
        }
      } else {
        print('❌ Failed to fetch balance: ${response.statusCode}');
      }
    } catch (e) {
      print('❌ Error: $e');
    } finally {
      setState(() {
        isLoading = false; // حتى لو حدث خطأ، نوقف اللودينج
      });
    }
  }

  // 🔵 زيادة الرصيد
  Future<void> increaseBalance() async {
    double amount = double.tryParse(amountController.text) ?? 0.0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('⚠️ أدخل مبلغ صالح')));
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('http://192.168.49.1/maqsaf_backend/parents/update_balance.php'),
        body: {
          'parent_id': widget.parentId,
          'amount': amount.toString(),
        },
      );

      final decodedData = json.decode(response.body);
      if (decodedData['status'] == 'success') {
        setState(() {
          balance += amount; // تحديث الرصيد محليًا
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('✅ تم تحديث الرصيد بنجاح')));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('❌ فشل التحديث')));
      }
    } catch (e) {
      print('❌ Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('رصيد ولي الأمر'), backgroundColor: Colors.teal),
      body: Center(
        child: isLoading
            ? CircularProgressIndicator()
            : Card(
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.account_balance_wallet, size: 50, color: Colors.teal),
                SizedBox(height: 10),
                Text('رصيدك الحالي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text('${balance.toStringAsFixed(2)} ر.ي',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.teal)),
                SizedBox(height: 20),

                // إدخال المبلغ لزيادة الرصيد
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'أدخل المبلغ',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),

                // زر زيادة الرصيد
                ElevatedButton(
                  onPressed: increaseBalance,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                  child: Text('زيادة الرصيد'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
