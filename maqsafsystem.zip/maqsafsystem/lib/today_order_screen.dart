import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class TodayOrdersScreen extends StatefulWidget {
  @override
  _TodayOrdersScreenState createState() => _TodayOrdersScreenState();
}

class _TodayOrdersScreenState extends State<TodayOrdersScreen> {
  List orders = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchTodayOrders();
  }

  // جلب الطلبات اليومية
  Future<void> fetchTodayOrders() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/login/get_today_orders.php'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        setState(() {
          orders = data['status'] == 'success' ? data['orders'] : [];
          isLoading = false;
        });
      }
    } catch (e) {
      print("Error fetching orders: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("📋 الطلبات اليومية"),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: fetchTodayOrders, // إعادة التحميل
          )
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : orders.isEmpty
          ? Center(child: Text("لا توجد طلبات اليوم", style: TextStyle(fontSize: 18)))
          : ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(
                orders[index]['Product_name'],
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                "📦 الكمية الإجمالية: ${orders[index]['total_quantity']}",
                style: TextStyle(fontSize: 16),
              ),
              leading: Icon(Icons.shopping_cart, color: Colors.blue),
            ),
          );
        },
      ),
    );
  }
}
