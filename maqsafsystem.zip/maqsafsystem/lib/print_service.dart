// import 'package:esc_pos_utils/esc_pos_utils.dart';
// import 'package:esc_pos_printer/esc_pos_printer.dart';
//
// class PrintService {
//   static Future<void> printReceipt(
//       String cashierName, List<Map<String, dynamic>> items, double total) async {
//     try {
//       final profile = await CapabilityProfile.load();
//       final printer = NetworkPrinter(PaperSize.mm80, profile);
//
//       final PosPrintResult connectResult = await printer.connect('192.168.1.100', port: 9100);
//
//       if (connectResult != PosPrintResult.success) {
//         print("❌ فشل الاتصال بالطابعة!");
//         return;
//       }
//
//       printer.text("🛒 فاتورة المبيعات", styles: PosStyles(align: PosAlign.center, height: PosTextSize.size2, width: PosTextSize.size2, bold: true));
//       printer.text("👤 الكاشير: $cashierName", styles: PosStyles(align: PosAlign.left));
//       printer.text("📅 ${DateTime.now()}", styles: PosStyles(align: PosAlign.left));
//
//       printer.hr(); // خط فاصل
//
//       for (var item in items) {
//         printer.text("${item['name']} × ${item['qty']}", styles: PosStyles(align: PosAlign.left));
//         printer.text("${item['price']} ر.س", styles: PosStyles(align: PosAlign.right));
//       }
//
//       printer.hr(); // خط فاصل
//       printer.text("💰 الإجمالي: $total ر.س", styles: PosStyles(align: PosAlign.right, height: PosTextSize.size2, width: PosTextSize.size2, bold: true));
//
//       printer.hr(ch: '=', linesAfter: 1); // خط فاصل مزدوج
//       printer.text("🎉 شكراً لتعاملكم معنا!", styles: PosStyles(align: PosAlign.center));
//
//       printer.cut(); // قص الورق
//       printer.disconnect(); // فصل الاتصال
//
//       print("✅ تم طباعة الفاتورة بنجاح!");
//     } catch (e) {
//       print("❌ خطأ أثناء الطباعة: $e");
//     }
//   }
// }
