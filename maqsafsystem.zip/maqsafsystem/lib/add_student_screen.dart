import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

class AddStudentScreen extends StatefulWidget {
  const AddStudentScreen({Key? key}) : super(key: key);

  @override
  State<AddStudentScreen> createState() => _AddStudentScreenState();
}

class _AddStudentScreenState extends State<AddStudentScreen> {
  TextEditingController studentNameController = TextEditingController();
  TextEditingController studentPasswordController = TextEditingController();
  TextEditingController gradeIdController = TextEditingController();
  TextEditingController parentNameController = TextEditingController();
  TextEditingController parentPasswordController = TextEditingController();
  TextEditingController relationshipController = TextEditingController();
  TextEditingController parentPhoneController = TextEditingController();
  TextEditingController parentEmailController = TextEditingController();

  DateTime? selectedDate;

  // **دالة التحقق من صحة الإدخال قبل الإرسال**
  bool validateInputs() {
    if (studentNameController.text.isEmpty ||
        studentPasswordController.text.isEmpty ||
        gradeIdController.text.isEmpty ||
        parentNameController.text.isEmpty ||
        parentPasswordController.text.isEmpty ||
        relationshipController.text.isEmpty ||
        parentPhoneController.text.isEmpty ||
        parentEmailController.text.isEmpty ||
        selectedDate == null) {
      showSnackBar("يرجى ملء جميع الحقول", Colors.red);
      return false;
    }

    // ✅ التحقق من أن كلمة مرور الطالب تتكون من 9 أرقام
    if (!RegExp(r'^\d{9}$').hasMatch(studentPasswordController.text)) {
      showSnackBar("يجب أن تتكون كلمة مرور الطالب من 9 أرقام فقط", Colors.red);
      return false;
    }

    // ✅ التحقق من أن كلمة مرور ولي الأمر تتكون من 9 أرقام
    if (!RegExp(r'^\d{9}$').hasMatch(parentPasswordController.text)) {
      showSnackBar("يجب أن تتكون كلمة مرور ولي الأمر من 9 أرقام فقط", Colors.red);
      return false;
    }
    if (!RegExp(r'^\d{9}$').hasMatch(parentPhoneController.text)) {
      showSnackBar("يجب أن يكون رقم الهاتف  9 أرقام فقط", Colors.red);
      return false;
    }

    if (parentNameController.text.trim().split(" ").length < 4) {
      showSnackBar("يجب إدخال اسم ولي الأمر رباعي", Colors.red);
      return false;
    }

    // ✅ التحقق من صحة البريد الإلكتروني
    if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(parentEmailController.text)) {
      showSnackBar("يرجى إدخال بريد إلكتروني صحيح", Colors.red);
      return false;
    }

    return true;
  }

// ** دالة لعرض رسالة خطأ **
  void showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
      ),
    );
  }

  // **دالة إرسال البيانات إلى السيرفر**
  Future<void> addStudent() async {
    if (!validateInputs()) return;

    String apiUrl = "http://192.168.49.1/login/add_student.php"; // تأكد من تشغيل السيرفر

    var response = await http.post(
      Uri.parse(apiUrl),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "student_name": studentNameController.text,
        "student_password": studentPasswordController.text,
        "date_of_birth": DateFormat('yyyy-MM-dd').format(selectedDate!),
        "grade_id": int.parse(gradeIdController.text),
        "parent_name": parentNameController.text,
        "parent_password": parentPasswordController.text,
        "relationship": relationshipController.text,
        "phone_number": parentPhoneController.text,
        "email": parentEmailController.text,
      }),
    );

    var data = jsonDecode(response.body);
    if (data["success"]) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("تمت إضافة الطالب وولي الأمر بنجاح!"),
        backgroundColor: Colors.green,
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("فشل الإضافة: ${data["message"]}"),
        backgroundColor: Colors.red,
      ));
    }
  }


  // **دالة لتصفير الحقول**
  void clearFields() {
    setState(() {
      studentNameController.clear();
      studentPasswordController.clear();
      gradeIdController.clear();
      parentNameController.clear();
      parentPasswordController.clear();
      relationshipController.clear();
      parentPhoneController.clear();
      parentEmailController.clear();
      selectedDate = null;
    });
  }


  // **دالة اختيار تاريخ الميلاد**
  Future<void> selectDate(BuildContext context) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2005, 1, 1),
      firstDate: DateTime(1990),
      lastDate: DateTime.now(),
    );

    if (picked != null) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFA0D3B5),

      appBar: AppBar(
        title: Text("نظام إدخال بيانات الطلاب", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          double maxWidth = constraints.maxWidth < 600 ? constraints.maxWidth * 0.9 : 600;

          return SingleChildScrollView(
            child: Center(
              child: Container(
                width: maxWidth,
                margin: EdgeInsets.symmetric(vertical: 20),
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      blurRadius: 10,
                      spreadRadius: 2,
                      offset: Offset(0, 5),
                    )
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    sectionTitle("إدخال بيانات الطالب"),
                    textField("اسم الطالب", studentNameController, Icons.person),
                    textField("كلمة المرور (9 أرقام)", studentPasswordController, Icons.lock, obscure: true),
                    GestureDetector(
                      onTap: () => selectDate(context),
                      child: AbsorbPointer(
                        child: textField(
                          selectedDate == null ? "تاريخ الميلاد (اضغط للاختيار)" : "تاريخ الميلاد: ${DateFormat('yyyy-MM-dd').format(selectedDate!)}",
                          TextEditingController(),
                          Icons.date_range,
                        ),
                      ),
                    ),
                    textField("رقم الصف", gradeIdController, Icons.grade),

                    SizedBox(height: 20),
                    sectionTitle("إدخال بيانات ولي الأمر"),
                    textField("اسم ولي الأمر (رباعي)", parentNameController, Icons.person_outline),
                    textField("كلمة مرور ولي الأمر (9 أرقام)", parentPasswordController, Icons.lock, obscure: true),
                    textField("علاقة ولي الأمر بالطالب", relationshipController, Icons.family_restroom),
                    textField("رقم الهاتف", parentPhoneController, Icons.phone),
                    textField("البريد الإلكتروني", parentEmailController, Icons.email),

                    SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: clearFields,
                            child: Text("تصفير الحقول", style: TextStyle(color: Colors.white)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                              padding: EdgeInsets.symmetric(vertical: 15),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            ),
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: addStudent, // استدعاء دالة الإضافة هنا
                            child: Text("إضافة", style: TextStyle(color: Colors.white)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                              padding: EdgeInsets.symmetric(vertical: 15),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget textField(String hint, TextEditingController controller, IconData icon, {bool obscure = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        decoration: InputDecoration(
          prefixIcon: Icon(icon),
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          filled: true,
          fillColor: Colors.grey.shade100,
        ),
      ),
    );
  }

  Widget sectionTitle(String title) {
    return Padding(
      padding: EdgeInsets.only(bottom: 10),
      child: Text(
        title,
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.teal),
      ),
    );
  }
}
