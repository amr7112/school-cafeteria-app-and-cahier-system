import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AddProductPage extends StatefulWidget {

  AddProductPage();

  @override
  _AddProductPageState createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  final _picker = ImagePicker();
  File? _image;

  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      }
    });
  }

  Future<void> _addProduct() async {
    if (_image == null) {
      print("No image selected");
      return;
    }

    // 1. رفع الصورة أولاً إلى السيرفر
    String imageUrl = await _uploadImage(_image!);

    // 2. إرسال بيانات المنتج (الاسم، السعر، الوصف، رابط الصورة)
    if (imageUrl.isNotEmpty) {
      bool isAdded = await _sendProductData(
        _nameController.text,
        double.parse(_priceController.text),
        _descriptionController.text,
        imageUrl,
      );

      if (isAdded) {
       // widget.onProductAdded(); // استدعاء الدالة لتحديث القائمة في الصفحة الرئيسية
        Navigator.pop(context); // إغلاق صفحة الإضافة بعد نجاح العملية
      }
    }
  }

  Future<String> _uploadImage(File imageFile) async {
    String uploadUrl = "http://192.168.49.1/login/upload_image.php";
    var request = http.MultipartRequest('POST', Uri.parse(uploadUrl));
    request.files.add(
      await http.MultipartFile.fromPath('image', imageFile.path),
    );

    var res = await request.send();
    var response = await http.Response.fromStream(res);
    var responseData = json.decode(response.body);

    if (responseData['status'] == 'success') {
      return responseData['image_url']; // رابط الصورة بعد الرفع
    } else {
      print('Failed to upload image: ${responseData['message']}');
      return "";
    }
  }

  Future<bool> _sendProductData(String name, double price, String description, String imageUrl) async {
    var response = await http.post(
      Uri.parse("http://192.168.49.1/login/products.php"),
      body: {
        'name': name,
        'price': price.toString(),
        'description': description,
        'image_url': imageUrl,
      },
    );

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      var responseBody = jsonDecode(response.body);
      if (responseBody['message'] == 'Product added successfully') {
        print('Product added successfully');
        return true;
      } else {
        print('Failed to add product: ${responseBody['message']}');
        return false;
      }
    } else {
      print('Failed to add product. Status code: ${response.statusCode}');
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('إضافة منتج جديد'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'اسم المنتج'),
            ),
            TextField(
              controller: _priceController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'السعر'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'الوصف'),
            ),
            SizedBox(height: 20),
            _image == null
                ? Text('لم يتم اختيار صورة.')
                : Image.file(_image!, height: 100),
            ElevatedButton(
              onPressed: _pickImage,
              child: Text('اختر صورة'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addProduct,
              child: Text('إضافة المنتج'),
            ),
          ],
        ),
      ),
    );
  }
}
