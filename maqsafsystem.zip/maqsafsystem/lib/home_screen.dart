import 'package:flutter/material.dart';
import 'package:maqsafsystem/cart_screen.dart';
import 'package:maqsafsystem/orders_screen.dart';
import 'package:maqsafsystem/parents_chat_list.dart';
import 'package:maqsafsystem/returns_order.dart';
import 'package:maqsafsystem/students_reports.dart';
import 'package:maqsafsystem/today_order_screen.dart';
import 'cashier_dashboard.dart';
import 'sales_screen.dart';

class MainScreen extends StatelessWidget {
  final String username;
  final List<Map<String, dynamic>> cartItems = []; // قائمة المنتجات في السلة
  final double totalPrice = 0.0; // المجموع الإجمالي

  MainScreen({required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("🔹 نظام الكاشير"),
        backgroundColor: Color(0xFF2B7A5B),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Colors.white),
            onPressed: () {
              // تسجيل خروج
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "👋 مرحبًا، $username",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 30),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,
                children: [
                  MenuButton(
                    icon: Icons.shopping_bag,
                    text: "📦 المنتجات",
                    onTap: () {
        
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CashierDashboard(
                          cashierName:username
                        )),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.request_page,
                    text: "📋الطلبات",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => OrdersScreen(
                              cashierName:username
        
                          ),
                        ),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.receipt,
                    text: "📋 سجل المبيعات",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SalesScreen()),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.receipt,
                    text: "🔄المردودات",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ReturnsPage()),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.receipt,
                    text: "📦قائمة تجهيز الوجبات",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => TodayOrdersScreen()),
                      );
                    },
                  ),
                  MenuButton(
                    icon: Icons.report,
                    text: "تقارير مشتريات الطلاب📄",
                    onTap: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context)=>StudentsReports()));
                    },
                  ),
                  MenuButton(
                    icon: Icons.settings,
                    text: "⚙️ الإعدادات",
                    onTap: () {
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MenuButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  MenuButton({required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        padding: EdgeInsets.symmetric(vertical: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: Color(0xFF2B7A5B), width: 2),
        ),
        elevation: 5,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 40, color: Color(0xFF2B7A5B)),
          SizedBox(height: 10),
          Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF2B7A5B),
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
