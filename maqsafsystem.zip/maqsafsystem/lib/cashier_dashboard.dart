import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CashierDashboard extends StatefulWidget {
  final String cashierName;
  CashierDashboard({required this.cashierName});
  @override
  _CashierDashboardState createState() => _CashierDashboardState();
}

class _CashierDashboardState extends State<CashierDashboard> {
  List students = []; // قائمة الطلاب مع الرصيد
  List orders = [];
  List<Map<String, dynamic>> products = [];
  Map<int, Map<String, dynamic>> cart = {}; // تخزين المنتجات مع كمياتها
  double totalPrice = 0.0;
  bool isLoading = true;
  TextEditingController commissionController = TextEditingController();



  @override
  @override
  void initState() {
    super.initState();
    fetchProducts();
    fetchStudents();
  }


  /// **جلب المنتجات من السيرفر**
  Future<void> fetchProducts() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/login/get_products.php'));

      print("Status Code: ${response.statusCode}");
      print("Body: ${response.body}");

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonData = jsonDecode(response.body);
        print("jsonData: $jsonData");

        if (jsonData['status'] == 'success' &&
            jsonData.containsKey('products') &&
            jsonData['products'] != null) {
          final List<dynamic> data = jsonData['products'];

          setState(() {
            products = data.map((product) => {
              "Product_id": int.parse(product['id'].toString()),
              "Product_name": product['name'],
              "Product_price": double.parse(product['price'].toString()),
              "Product_description": product['description'],
              "Product_image_url": product['image_url'],
              "note": product['note'],
              "Category_name": product['category'],
            }).toList();
            isLoading = false;
          });
        } else {
          throw Exception("البيانات غير صحيحة أو لا تحتوي على منتجات");
        }
      } else {
        throw Exception("خطأ في الاتصال بالسيرفر (${response.statusCode})");
      }
    } catch (e) {
      print("حدث استثناء: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("حدث خطأ أثناء جلب المنتجات: $e")),
      );
    }
  }

  /// **إضافة منتج للسلة أو زيادة كميته**
  void addToCart(Map<String, dynamic> product) {
    setState(() {
      int productId = product["Product_id"];
      if (cart.containsKey(productId)) {
        cart[productId]!["quantity"] += 1;
      } else {
        cart[productId] = {
          "Product_id": productId,
          "Product_name": product["Product_name"],
          "Product_price": product["Product_price"],
          "quantity": 1,
        };
      }
      totalPrice += product["Product_price"];
    });
  }



  /// **تقليل كمية المنتج أو حذفه إذا كانت الكمية 0**
  void removeFromCart(int productId) {
    setState(() {
      if (cart.containsKey(productId)) {
        totalPrice -= cart[productId]!["Product_price"];
        if (cart[productId]!["quantity"] > 1) {
          cart[productId]!["quantity"] -= 1;
        } else {
          cart.remove(productId);
        }
      }
    });
  }

  Future<void> fetchStudents() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/login/get_students_account.php'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == 'success') {
          setState(() {
            students = data['students'] ?? [];
          });
        }
      }
    } catch (e) {
      print("❌ Error fetching students: $e");
    }
  }

  /// **إتمام الطلب**
  Future<void> checkout({String? studentId, double commissionPercent = 0.0}) async {
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("السلة فارغة!")),
      );
      return;
    }
    print("commissionPercent");
    print(commissionPercent);

    // 🧮 حساب العمولة بناءً على القيمة المدخلة يدويًا
    double commissionAmount = (totalPrice * commissionPercent) / 100;
    print("commissionAmount");
    print(commissionAmount);
    double totalWithCommission = totalPrice + commissionAmount;
    print(commissionPercent);


    try {
      final response = await http.post(
        Uri.parse('http://192.168.49.1/login/add_sale.php'),
        body: {
          'cashier_name': widget.cashierName,
          'sales_data': jsonEncode(cart.values.toList()),
          'student_id': studentId ?? 'cash', // إذا كان نقدي يتم إرسال 'cash'
          'commission': commissionAmount.toStringAsFixed(2), // 💰 العمولة
          'total': totalWithCommission.toStringAsFixed(2), // الإجمالي مع العمولة
        },
      );
    print(commissionPercent);
      print("Response body: ${response.body}");

      final data = json.decode(response.body);

      if (data['status'] == 'success') {
        setState(() {
          cart.clear();
          totalPrice = 0.0;
          commissionPercent = 0.0; // إعادة تعيين العمولة بعد الشراء
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("✅ تمت عملية البيع بنجاح!")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ فشل في تسجيل البيع! ${data['message']}")),
        );
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ حدث خطأ أثناء إرسال البيانات: $e")),
      );
    }
  }


  void showPaymentOptions(double commissionPercent){
    showDialog(
      context: context,
      builder: (context) {
        String selectedStudentId = '';
        double studentBalance = 0.0;

        return AlertDialog(
          title: Text("اختر طريقة الدفع"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton(
                onPressed: () {
                  print(commissionPercent);
                  Navigator.pop(context);
                  checkout(studentId: 'cash', commissionPercent: commissionPercent);
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: Text("💵 الدفع نقدًا", style: TextStyle(color: Colors.white)),
              ),
              SizedBox(height: 10),

              // ✅ Dropdown مع البحث عن الطالب
              students.isNotEmpty
                  ? DropdownSearch<String>(
                items: students.map((student) {
                  return "${student['student_name']} - الرصيد: ${student['balance']} ر.ي";
                }).toList(),
                dropdownBuilder: (context, selectedItem) {
                  return Text(
                    selectedItem ?? "🔍 اختر الطالب",
                    style: TextStyle(color: Colors.grey),
                  );
                },
                popupProps: PopupProps.menu(
                  showSearchBox: true, // ✅ تمكين البحث
                  searchFieldProps: TextFieldProps(
                    decoration: InputDecoration(hintText: "ابحث عن طالب..."),
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    selectedStudentId = students.firstWhere(
                          (s) => "${s['student_name']} - الرصيد: ${s['balance']} ر.ي" == value,
                    )['student_id'].toString();

                    studentBalance = double.tryParse(
                      students.firstWhere((s) => s['student_id'].toString() == selectedStudentId)['balance'].toString(),
                    ) ??
                        0.0;
                  });
                },
              )
                  : Text("❌ لا يوجد طلاب متاحين"),

              SizedBox(height: 10),

              ElevatedButton(
                onPressed: () {
                  if (selectedStudentId.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("يرجى اختيار طالب أو الدفع نقدًا")),
                    );
                    return;
                  }
                  if (studentBalance < totalPrice) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("❌ الرصيد غير كافٍ!")),
                    );
                    return;
                  }
                  Navigator.pop(context);
                  checkout(studentId: selectedStudentId, commissionPercent: commissionPercent); // ✅
                },
                child: Text("💳 الدفع من حساب الطالب"),
              ),
            ],
          ),
        );
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("لوحة تحكم الكاشير"),
        backgroundColor: Color(0xFF2B7A5B),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: showCartDialog,
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF2B7A5B)))
          : Column(
        children: [
          Expanded(
            child: GridView.builder(
              physics: BouncingScrollPhysics(),
              padding: EdgeInsets.all(10),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.8,
              ),
              itemCount: products.length,
              itemBuilder: (context, index) {
                var product = products[index];
                return Card(
                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 5,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Image.network(

                          product['Product_image_url'],
                          height: double.infinity,
                          fit: BoxFit.contain,
                          width: 250,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Column(
                          children: [
                            Text(
                              product['Product_name'],
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              textAlign: TextAlign.center,
                            ),
                            Text("${product['Product_price']} ر.ي", style: TextStyle(color: Colors.green)),
                            Text(
                              product['Category_name'],
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              product['note'],
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              textAlign: TextAlign.center,
                            ),

                          ],
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () => addToCart(product),
                        style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF2B7A5B),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))
                        ),
                        child: Text("إضافة للسلة", style: TextStyle(
                          color: Colors.white,

                        )),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  /// **عرض السلة في نافذة منبثقة مع تحديث فوري**
  void showCartDialog() {
    double commissionPercent = 10.0; // القيمة الابتدائية للعمولة (مثلاً 10%)

    TextEditingController commissionController =
    TextEditingController(text: commissionPercent.toString());

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) {
          // حساب العمولة بناءً على النسبة
          double percent = double.tryParse(commissionController.text) ?? 0.0;
          double commissionAmount = (totalPrice * percent) / 100;
          double totalWithCommission = totalPrice + commissionAmount;

          return AlertDialog(
            title: Text("🛒 سلة المشتريات"),
            content: cart.isEmpty
                ? Text("السلة فارغة")
                : Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ...cart.values.map((item) {
                  return ListTile(
                    title: Text(item["Product_name"]),
                    subtitle: Text(
                        "الكمية: ${item["quantity"]}  ${item["Product_price"]} ر.ي"),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon:
                          Icon(Icons.remove_circle, color: Colors.red),
                          onPressed: () {
                            removeFromCart(item["Product_id"]);
                            setState(() {});
                            setStateDialog(() {});
                          },
                        ),
                        Text("${item["quantity"]}",
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                        IconButton(
                          icon: Icon(Icons.add_circle,
                              color: Colors.green),
                          onPressed: () {
                            addToCart(item);
                            setState(() {});
                            setStateDialog(() {});
                          },
                        ),
                      ],
                    ),
                  );
                }).toList(),
                SizedBox(height: 12),

                /// 🟡 إدخال العمولة كنسبة مئوية
                TextField(
                  controller: commissionController,
                  keyboardType:
                  TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: "العمولة (%)",
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setStateDialog(() {});
                  },
                ),
                SizedBox(height: 8),

                /// ✅ عرض تفاصيل العمولة
                Text("قيمة العمولة: ${commissionAmount.toStringAsFixed(2)} ر.ي",
                    style: TextStyle(color: Colors.orange)),
                Text("الإجمالي بعد العمولة: ${totalWithCommission.toStringAsFixed(2)} ر.ي",
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.blue)),
              ],
            ),
            actions: [
              Text("الإجمالي بدون عمولة: ${totalPrice.toStringAsFixed(2)} ر.ي"),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    commissionPercent = double.tryParse(commissionController.text) ?? 0.0;
                  });
                  Navigator.pop(context);
                  showPaymentOptions(commissionPercent);
                },
                style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF2B7A5B)),
                child: Text("إتمام الطلب", style: TextStyle(color: Colors.white)),
              ),
            ],
          );
        },
      ),
    );
  }
}
