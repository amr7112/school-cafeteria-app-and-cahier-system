import 'package:flutter/material.dart';
import 'add_product.dart'; // صفحة إضافة منتج
import 'delete_product_screen.dart'; // صفحة حذف منتج
import 'edit_product_screen.dart'; // صفحة تعديل منتج

class controlProduct extends StatelessWidget {
  const controlProduct({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("إدارة المنتجات"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            buildOptionCard(
              context,
              title: "إضافة منتج جديد",
              icon: Icons.add,
              color: Colors.green,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>  AddProductScreen()),
                );
              },
            ),
            const SizedBox(height: 20),
            buildOptionCard(
              context,
              title: "حذف منتج",
              icon: Icons.delete,
              color: Colors.red,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const DeleteProductScreen()),
                );
              },
            ),
            const SizedBox(height: 20),
            buildOptionCard(
              context,
              title: "تعديل منتج",
              icon: Icons.edit,
              color: Colors.blue,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const EditProductScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget buildOptionCard(BuildContext context,
      {required String title,
      required IconData icon,
      required Color color,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(15),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26, blurRadius: 5, offset: Offset(2, 2)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 30),
            const SizedBox(width: 10),
            Text(
              title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
