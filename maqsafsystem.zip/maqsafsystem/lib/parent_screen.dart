import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:maqsafsystem/parents_balance_screen.dart';
import 'dart:convert';

class ParentsScreen extends StatefulWidget {
  @override
  _ParentsScreenState createState() => _ParentsScreenState();
}

class _ParentsScreenState extends State<ParentsScreen> {
  List<Map<String, dynamic>> parents = [];
  List<Map<String, dynamic>> filteredParents = [];
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchParents();
  }

  // جلب بيانات أولياء الأمور من قاعدة البيانات
  Future<void> fetchParents() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/maqsaf_backend/parents/fetch_parents.php'));

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);

        if (decodedData['status'] == 'success' && decodedData['parents'] != null) {
          setState(() {
            parents = List<Map<String, dynamic>>.from(decodedData['parents']);
            filteredParents = parents;
          });
        }
      } else {
        print('Failed to fetch parents: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  // دالة البحث
  void filterSearch(String query) {
    setState(() {
      if (query.isEmpty) {
        filteredParents = parents;
      } else {
        filteredParents = parents
            .where((parent) =>
        parent['parent_name'].toLowerCase().contains(query.toLowerCase()) ||
            parent['phone_number'].contains(query))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('أولياء الأمور'), backgroundColor: Colors.teal),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: searchController,
              decoration: InputDecoration(
                labelText: 'بحث عن ولي أمر',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: filterSearch,
            ),
            SizedBox(height: 20),
            Expanded(
              child: filteredParents.isEmpty
                  ? Center(child: CircularProgressIndicator())
                  : ListView.builder(
                itemCount: filteredParents.length,
                itemBuilder: (context, index) {
                  final parent = filteredParents[index];
                  return Card(
                    child: ListTile(
                      leading: Icon(Icons.person, color: Colors.teal),
                      title: Text(parent['parent_name']),
                      subtitle: Text('رقم الهاتف: ${parent['phone_number']}'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BalanceScreen(parentId: parent['parent_id']),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
