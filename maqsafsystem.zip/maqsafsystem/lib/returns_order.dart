

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
class ReturnsPage extends StatefulWidget {
  @override
  _ReturnsPageState createState() => _ReturnsPageState();
}

class _ReturnsPageState extends State<ReturnsPage> {
  List returnedOrders = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchReturnedOrders(); // جلب المردودات عند تحميل الصفحة
  }


  // جلب المردودات من قاعدة البيانات
  Future<void> fetchReturnedOrders() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.49.1/login/get_returned_orders.php'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == 'success') {
          setState(() {
            returnedOrders = data['orders'];
            isLoading = false;
          });
        } else {
          setState(() {
            returnedOrders = [];
            isLoading = false;
          });
        }
      }
    } catch (e) {
      print("Error fetching returned orders: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("المردودات")),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : returnedOrders.isEmpty
          ? Center(child: Text("لا توجد مردودات"))
          : ListView.builder(
        itemCount: returnedOrders.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(
                returnedOrders[index]['Product_name'],
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("🔢 الكمية: ${returnedOrders[index]['quantity']}"),
                  Text("🔢 اسم الطالب: ${returnedOrders[index]['student_name']}"),
                  Text("💵 الرصيد المرتجع: ${returnedOrders[index]['total_price']} ريال"),
                  Text("📅 التاريخ: ${returnedOrders[index]['return_date']}"),
                  Text("💰 الإجمالي: ${(int.parse(returnedOrders[index]['quantity']) * double.parse(returnedOrders[index]['total_price'])).toStringAsFixed(2)} ريال"),
                ],
              ),
              trailing: Icon(Icons.refresh, color: Colors.green),
            ),
          );

        },
      ),
    );
  }
}
