import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class StudentSalesReportScreen extends StatefulWidget {
  final String studentId;
  final String studentName;

  const StudentSalesReportScreen({
    super.key,
    required this.studentId,
    required this.studentName,
  });

  @override
  _StudentSalesReportScreenState createState() =>
      _StudentSalesReportScreenState();
}

class _StudentSalesReportScreenState extends State<StudentSalesReportScreen> {
  List<Map<String, dynamic>> salesData = [];
  bool isLoading = true;

  DateTime? _fromDate;
  DateTime? _toDate;

  @override
  void initState() {
    super.initState();
    fetchSalesData();
  }

  Future<void> fetchSalesData() async {
    final url = Uri.parse(
        'http://192.168.49.1/login/student_sales.php?student_id=${widget.studentId}');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          salesData = List<Map<String, dynamic>>.from(data['sales']);
        });
      }
    }
    setState(() => isLoading = false);
  }

  List<Map<String, dynamic>> get filteredSales {
    return salesData.where((sale) {
      final saleDate = DateTime.tryParse(sale['sale_date']) ?? DateTime(2000);
      final fromCheck = _fromDate == null || !saleDate.isBefore(_fromDate!);
      final toCheck = _toDate == null || !saleDate.isAfter(_toDate!);
      return fromCheck && toCheck;
    }).toList();
  }

  Future<void> _selectDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        _fromDate = picked.start;
        _toDate = picked.end;
      });
    }
  }

  Future<void> exportToPDF() async {
    final pdf = pw.Document();

    final arabicFont = await rootBundle.load("assets/fonts/Amiri-Regular.ttf");
    final ttf = pw.Font.ttf(arabicFont);

    double grandTotal = 0;
    for (final sale in filteredSales) {
      final items = sale['items'] as List<dynamic>;
      final commission = double.tryParse(sale['commission']?.toString() ?? '0') ?? 0.0;

      for (final item in items) {
        final quantity = int.tryParse(item['quantity']) ?? 0;
        final price = double.tryParse(item['price_per_unit']) ?? 0.0;
        final total = (quantity * price) + commission;
        grandTotal += total;
      }
    }

    // ✅ إنشاء صفحة التقرير
    pdf.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(
          base: ttf,
          bold: ttf,
        ),
        build: (context) {
          return [
            // العنوان الرئيسي
            pw.Container(
              alignment: pw.Alignment.centerRight,
              child: pw.Text(
                "تقرير مشتريات الطالب: ${widget.studentName}",
                style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
                textDirection: pw.TextDirection.rtl,
              ),
            ),
            pw.SizedBox(height: 15),

            ...filteredSales.map((sale) {
              final items = sale['items'] as List<dynamic>;
              final commission = double.tryParse(sale['commission']?.toString() ?? '0') ?? 0.0;
              double saleTotalWithCommission = 0.0;

              return pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text(" التاريخ: ${sale['sale_date']}", textDirection: pw.TextDirection.rtl),
                  pw.Text(" الكاشير: ${sale['cashier_name']}", textDirection: pw.TextDirection.rtl),
                  pw.SizedBox(height: 5),

                  pw.Table(
                    border: pw.TableBorder.all(),
                    columnWidths: {
                      0: pw.FlexColumnWidth(2), // التاريخ
                      1: pw.FlexColumnWidth(3), // المنتج
                      2: pw.FlexColumnWidth(1), // الكمية
                      3: pw.FlexColumnWidth(2), // السعر
                      4: pw.FlexColumnWidth(2), // العمولة
                      5: pw.FlexColumnWidth(2), // الإجمالي
                    },
                    children: [
                      pw.TableRow(
                        decoration: pw.BoxDecoration(color: PdfColors.grey300),
                        children: [
                          pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text("التاريخ", textDirection: pw.TextDirection.rtl, textAlign: pw.TextAlign.center)),
                          pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text("الإجمالي", textDirection: pw.TextDirection.rtl, textAlign: pw.TextAlign.center)),
                          pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text("العمولة", textDirection: pw.TextDirection.rtl, textAlign: pw.TextAlign.center)),
                          pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text("السعر", textDirection: pw.TextDirection.rtl, textAlign: pw.TextAlign.center)),
                          pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text("الكمية", textDirection: pw.TextDirection.rtl, textAlign: pw.TextAlign.center)),
                          pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text("المنتج", textDirection: pw.TextDirection.rtl, textAlign: pw.TextAlign.center)),
                        ],
                      ),
                      ...items.map((item) {
                        final quantity = int.tryParse(item['quantity']) ?? 0;
                        final price = double.tryParse(item['price_per_unit']) ?? 0.0;
                        final total = (quantity * price) + commission;
                        saleTotalWithCommission += total;

                        return pw.TableRow(
                          children: [
                            pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text(sale['sale_date'], textAlign: pw.TextAlign.center)),
                            pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text(total.toStringAsFixed(2), textAlign: pw.TextAlign.center)),
                            pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text(commission.toStringAsFixed(2), textAlign: pw.TextAlign.center)),
                            pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text(price.toStringAsFixed(2), textAlign: pw.TextAlign.center)),
                            pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text("$quantity", textAlign: pw.TextAlign.center)),
                            pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text(item['product_name'], textDirection: pw.TextDirection.rtl)),

                          ],
                        );
                      }).toList(),
                    ],
                  ),

                  pw.SizedBox(height: 5),
                  pw.Text(
                    "الإجمالي للعملية مع العمولة: ${saleTotalWithCommission.toStringAsFixed(2)} ريال",
                    textDirection: pw.TextDirection.rtl,
                  ),
                  pw.Divider(thickness: 1),
                ],
              );
            }).toList(),

            pw.SizedBox(height: 15),

            // ✅ إجمالي المشتريات النهائي
            pw.Container(
              alignment: pw.Alignment.centerRight,
              child: pw.Text(
                " إجمالي المشتريات: ${grandTotal.toStringAsFixed(2)} ريال",
                style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
                textDirection: pw.TextDirection.rtl,
              ),
            ),

            pw.SizedBox(height: 10),

            // التاريخ النهائي في أسفل التقرير
            pw.Container(
              alignment: pw.Alignment.centerRight,
              child: pw.Text(
                " تم إصدار التقرير بتاريخ: ${DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now())}",
                style: const pw.TextStyle(fontSize: 10),
                textDirection: pw.TextDirection.rtl,
              ),
            ),
          ];
        },
      ),
    );

    await Printing.layoutPdf(onLayout: (format) => pdf.save());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(" تقرير${widget.studentName}"),
        backgroundColor: Colors.teal,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                ElevatedButton.icon(
                  onPressed: _selectDateRange,
                  icon: const Icon(Icons.date_range),
                  label: Text(_fromDate == null || _toDate == null
                      ? "تحديد فترة"
                      : "${DateFormat('yyyy-MM-dd').format(_fromDate!)} - ${DateFormat('yyyy-MM-dd').format(_toDate!)}"),
                ),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: exportToPDF,
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text("PDF",style:TextStyle(
                    fontSize: 10
                  ),),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: filteredSales.isEmpty
                ? const Center(child: Text("لا توجد مشتريات"))
                : ListView.builder(
              itemCount: filteredSales.length,
              itemBuilder: (context, index) {
                final sale = filteredSales[index];
                final items = sale['items'] as List<dynamic>;
                return Card(
                  margin:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  child: ListTile(
                    title: Text("${sale['sale_date']}"),
                    subtitle: Text("الكاشير: ${sale['cashier_name']}"),
                    trailing: Text("${sale['total_price']} ريال"),
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text("تفاصيل المشتريات"),
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: items.map((item) {
                              final total = int.parse(item['quantity']) *
                                  double.parse(item['price_per_unit']);
                              return ListTile(
                                title: Text(item['product_name']),
                                subtitle: Text(
                                    "${item['quantity']} × ${item['price_per_unit']}"),
                                trailing: Text(
                                    "=${total.toStringAsFixed(2)} ريال"),
                              );
                            }).toList(),
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
