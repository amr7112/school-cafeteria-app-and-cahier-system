import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:maqsafsystem/admin_screen.dart';
import 'dart:convert';

import 'package:maqsafsystem/home_screen.dart';


class login_Screen extends StatefulWidget {
  @override
  _login_ScreenState createState() => _login_ScreenState();
}

class _login_ScreenState extends State<login_Screen> {
  bool isAgreed = false;
  bool isLoading = false;
  TextEditingController userNameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String errorMessage = "";

  Future<void> login() async {
    setState(() {
      isLoading = true;
    });

    final response = await http.post(
      Uri.parse('http://192.168.49.1/login/login.php'),
      body: {
        'userName': userNameController.text.trim(),
        'password': passwordController.text.trim(),
      },
    );

    setState(() {
      isLoading = false;
    });

    try {
      final data = jsonDecode(response.body);

      if (data['status'] == 'success') {
        String role = data['role'];
        String user_id = data['user_id'];
        String cashierName = data['Username'];
        String adminName = data['Username'];

        if (role == 'admin') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => AdminScreen(username: adminName, user_id:user_id)),
          );
        } else if (role == 'cashier') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => MainScreen(username: cashierName)),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("⚠️ خطأ: ${data['message']}")),
        );
      }
    } catch (e) {
      print("JSON Error: $e");
      print("Response Body: ${response.body}");

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("⚠️ خطأ في استجابة السيرفر!")),
      );
    }
  }

  void validateAndLogin() {
    setState(() {
      errorMessage = "";
    });

    login();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFA0D3B5),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF2B7A5B)))
          : Center(
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(20),
            margin: EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '!مرحبا بك',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2B7A5B),
                  ),
                ),
                Text(
                  'تسجيل دخول',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2B7A5B),
                  ),
                ),
                SizedBox(height: 16),
                TextField(
                  controller: userNameController,
                  decoration: InputDecoration(
                    hintText: 'أدخل اسم المستخدم',
                    prefixIcon: Icon(Icons.person),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade100,
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'أدخل كلمة المرور',
                    prefixIcon: Icon(Icons.lock),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade100,
                  ),
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Checkbox(
                      value: isAgreed,
                      onChanged: (value) {
                        setState(() {
                          isAgreed = value!;
                        });
                      },
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          isAgreed = !isAgreed;
                        });
                      },
                      child: Text(
                        'أوافق على الشروط و الأحكام',
                        style: TextStyle(color: Colors.blue),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: isAgreed ? validateAndLogin : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2B7A5B),
                    padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'متابعة',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
                if (errorMessage.isNotEmpty) ...[
                  SizedBox(height: 10),
                  Text(
                    errorMessage,
                    style: TextStyle(color: Colors.red),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
