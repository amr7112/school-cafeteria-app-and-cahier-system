import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class DeleteProductScreen extends StatefulWidget {
  const DeleteProductScreen({super.key});

  @override
  State<DeleteProductScreen> createState() => _DeleteProductScreenState();
}

class _DeleteProductScreenState extends State<DeleteProductScreen> {
  List<dynamic> products = [];

  @override
  void initState() {
    super.initState();
    fetchProducts();
  }

  Future<void> fetchProducts() async {
    var url = Uri.parse("http://192.168.49.1/login/get_products.php");
    var response = await http.get(url);
    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        setState(() {
          products =
              jsonResponse['products'] ?? []; // تأكد من أن القائمة ليست null
        });
      }


    }
  }

  Future<void> deleteProduct(String productId) async {
    var url = Uri.parse("http://192.168.49.1/login/delete_product.php");
    var response = await http.post(url, body: {
      'Product_id': productId,
    });
    print("Deleting product with ID: $productId");

    var jsonResponse = json.decode(response.body);
    if (jsonResponse['status'] == 'success') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(jsonResponse['message'])),
      );
      fetchProducts(); // إعادة تحميل المنتجات بعد الحذف
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(jsonResponse['message'])),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("حذف منتج"),
        backgroundColor: Color(0xFF2B7A5B),

      ),

      body: products.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                var product = products[index];

                String productImage = product['image_url'] ?? '';
                String productName = product['name'] ?? 'غير معروف';
                String productPrice =
                    product['price']?.toString() ?? 'غير متوفر';
                String productId = product['id']?.toString() ?? '';

                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: productImage.isNotEmpty
                        ? Image.network(
                            productImage, // تم التعديل هنا
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                          )
                        : const Icon(Icons.image_not_supported),
                    title: Text(productName),
                    subtitle: Text("السعر: $productPrice"),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text("تأكيد الحذف"),
                            content:
                                const Text("هل أنت متأكد من حذف هذا المنتج؟"),
                            actions: [
                              TextButton(
                                child: const Text("إلغاء"),
                                onPressed: () => Navigator.pop(context),
                              ),
                              ElevatedButton(
                                child: const Text("حذف"),
                                onPressed: () async {
                                  Navigator.pop(context);
                                  showDialog(
                                    context: context,
                                    barrierDismissible: false,
                                    builder: (_) => const Center(child: CircularProgressIndicator()),
                                  );

                                  await deleteProduct(productId);

                                  Navigator.pop(context); // إغلاق التحميل بعد انتهاء الحذف
                                },

                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                );
              }),
    );
  }
}
