import 'package:flutter/material.dart';
import 'print_service.dart';

class CartScreen extends StatelessWidget {
  final String cashierName;
  final List<Map<String, dynamic>> cartItems;
  final double totalPrice;

  CartScreen({required this.cashierName, required this.cartItems, required this.totalPrice});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("🛒 السلة")),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cartItems.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(cartItems[index]['name']),
                  subtitle: Text("الكمية: ${cartItems[index]['qty']}"),
                  trailing: Text("${cartItems[index]['price']} ر.ي"),
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Text("💰 الإجمالي: $totalPrice ر.ي", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                ElevatedButton.icon(
                  onPressed: () {
                   // PrintService.printReceipt(cashierName, cartItems, totalPrice);
                  },
                  icon: Icon(Icons.print),
                  label: Text("🖨️ طباعة الفاتورة"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
