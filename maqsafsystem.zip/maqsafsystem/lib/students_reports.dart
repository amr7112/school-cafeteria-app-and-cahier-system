import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:maqsafsystem/StudentSalesReportScreen.dart';

class StudentsReports extends StatefulWidget {
  @override
  _StudentsReportsState createState() => _StudentsReportsState();
}

class _StudentsReportsState extends State<StudentsReports> {
  List<Map<String, dynamic>> students = [];
  bool isLoading = true;
  TextEditingController searchController = TextEditingController();

  String _searchQuery = '';
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    fetchStudents(); // ✅
  }

  @override
  void dispose() {
    _debounce?.cancel();
    searchController.dispose();
    super.dispose();
  }

  // ✅ جلب قائمة الطلاب
  Future<void> fetchStudents() async {
    try {
      var url = Uri.parse('http://192.168.49.1/login/try.php');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == 'success') {
          setState(() {
            students = List<Map<String, dynamic>>.from(data['students']);
            isLoading = false;
          });
        } else {
          setState(() {
            students = [];
            isLoading = false;
          });
        }
      }
    } catch (e) {
      print('❌ خطأ أثناء جلب البيانات: $e');
    }
  }

  void _onSearchChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(Duration(milliseconds: 500), () {
      setState(() {
        _searchQuery = query;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final filteredStudents = students.where((student) {
      return student['student_name']
          .toString()
          .toLowerCase()
          .contains(_searchQuery.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text("التقارير"),
        backgroundColor: Color(0xFF2B7A5B),
        elevation: 20,
        titleSpacing: 95,
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: "بحث...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              onChanged: _onSearchChanged,
            ),
          ),
          Expanded(
            child: isLoading
                ? Center(child: CircularProgressIndicator())
                : ListView.builder(
              itemCount: filteredStudents.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(filteredStudents[index]['student_name']),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => StudentSalesReportScreen(
                          studentId: filteredStudents[index]['student_id'].toString(),
                          studentName: filteredStudents[index]['student_name'],
                        ),
                      ),
                    );
                  },

                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
