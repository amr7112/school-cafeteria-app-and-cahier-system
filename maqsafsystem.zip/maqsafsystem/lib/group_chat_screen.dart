import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class GroupChatScreen extends StatefulWidget {
  final String currentUserId;

  GroupChatScreen({required this.currentUserId});

  @override
  _GroupChatScreenState createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  TextEditingController _messageController = TextEditingController();
  List<Map<String, dynamic>> messages = [];
  Timer? _timer;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    fetchMessages();
    _timer = Timer.periodic(Duration(seconds: 5), (timer) {
      fetchMessages(autoUpdate: true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  /// جلب الرسائل الجماعية
  Future<void> fetchMessages({bool autoUpdate = false}) async {
    final response = await http.get(Uri.parse("http://192.168.49.1/login/get_group_messages.php"));

    if (response.statusCode == 200) {

      final jsonData = json.decode(response.body);
      if (jsonData is List) {
        List<Map<String, dynamic>> newMessages =
        List<Map<String, dynamic>>.from(jsonData);
        if (jsonEncode(messages) != jsonEncode(newMessages)) {
          setState(() {
            messages = newMessages;
          });
        }
      } else if (jsonData is Map) {
        // هنا يمكن التعامل مع الرد الذي يحتوي على خطأ أو رسالة أخرى
        print("❌ حدث خطأ: ${jsonData['error']}");
        // يمكنك اتخاذ إجراء إضافي هنا مثل عرض رسالة للمستخدم
      }
    } else {
      print("❌ خطأ في الاستجابة من السيرفر: ${response.statusCode}");
    }
  }

  /// إرسال رسالة نصية أو صورة
  Future<void> sendMessage({String? imageUrl}) async {
    final messageText = _messageController.text.trim();
    if (messageText.isEmpty && imageUrl == null) return;

    final response = await http.post(
      Uri.parse("http://192.168.49.1/login/send_group_message.php"),
      body: {
        "sender_id": widget.currentUserId,
        "message": messageText,
        "image_name": imageUrl ?? "",
      },
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse["success"] != null) {
        _messageController.clear();
        fetchMessages();
      } else {
        print("❌ فشل إرسال الرسالة: ${jsonResponse['error']}");
      }
    } else {
      print("❌ خطأ في الاستجابة من السيرفر");
    }
  }

  /// رفع الصورة إلى السيرفر وإرسال اسمها إلى قاعدة البيانات
  Future<void> sendImage(File imageFile) async {
    var request = http.MultipartRequest(
        "POST", Uri.parse("http://192.168.49.1/login/upload_group_image.php"));

    request.fields['sender_id'] = widget.currentUserId;
    request.files.add(await http.MultipartFile.fromPath("image_name", imageFile.path));

    var response = await request.send();
    String responseData = await response.stream.bytesToString();

    print("📩 Response: $responseData"); // طباعة الرد للتحقق

    try {
      final jsonResponse = json.decode(responseData);
      if (jsonResponse['status'] == 'success') {
        sendMessage(imageUrl: jsonResponse['image_name']);
      } else {
        print("❌ فشل رفع الصورة: ${jsonResponse['message'] ?? 'خطأ غير معروف'}");
      }
    } catch (e) {
      print("❌ خطأ في تحليل JSON: $e");
    }
  }


  /// اختيار صورة من المعرض أو الكاميرا
  Future<void> pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);
    if (pickedFile != null) {
      File imageFile = File(pickedFile.path);
      await sendImage(imageFile);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("المحادثة الجماعية")),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final isMe = msg['sender_id'] == widget.currentUserId;
                final imageName = msg['image_name'] ?? "";

                return Align(
                  alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isMe ? Colors.blue[100] : Colors.grey[300],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${msg['sender_name']}", // استخدام sender_name بدلاً من sender_id
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),

                        if (imageName.isNotEmpty)

                          Image.network(
                            msg['image_name'] ?? "",

                            width: 200,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              print(msg['image_name']);

                              return Text("⚠️ الصورة غير موجودة");

                            },

                          ),


                        if (msg['message'].isNotEmpty)
                          Padding(
                            padding: EdgeInsets.only(top: imageName.isNotEmpty ? 5 : 0),
                            child: Text(msg['message']),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.photo, color: Colors.green),
                  onPressed: () => pickImage(ImageSource.gallery),
                ),
                IconButton(
                  icon: Icon(Icons.camera_alt, color: Colors.orange),
                  onPressed: () => pickImage(ImageSource.camera),
                ),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(hintText: "اكتب رسالتك..."),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: Colors.blue),
                  onPressed: sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
